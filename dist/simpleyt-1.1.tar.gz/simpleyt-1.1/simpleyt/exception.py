class SimpleYTException(Exception):
    pass 